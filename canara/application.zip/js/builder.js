(function () {
	"use strict";	

	require('./modules/ui.js');
	require('./modules/builder.js');
	require('./modules/config.js');
	require('./modules/utils.js');
	require('./modules/canvasElement.js');
	require('./modules/styleeditor.js');
	require('./modules/imageLibrary.js');
	require('./modules/content.js');
	require('./modules/sitesettings.js');
	require('./modules/publishing.js');
	require('./modules/export.js');
	require('./modules/preview.js');
	require('./modules/revisions.js');
	require('./modules/templates.js');

}());